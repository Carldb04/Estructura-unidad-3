/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package colalifo;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;
import javax.swing.JOptionPane;

/**
 *
 * @author iruku
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int opciones;
        Stack<ColasLifo> miLifo = new Stack<>();
        ColasLifo coli = new ColasLifo();
        ColasLifo coli2 = new ColasLifo();
        ColasLifo coli3 = new ColasLifo();

        do {
            JOptionPane.showMessageDialog(null, "Oprime 1 para agregar Datos\n"
                    + "presione 2a para consultar el último valor de la cola Lifo\n"
                    + "presione 3 para borrar el último elemento\n"
                    + "presione 4 para verificar si la cola Lifo está vacía\n"
                    + "presione 5 para ver la cantidad de elementos que tiene la cola\n"
                    + "presione 6 para buscar la posición en que se encuentra un elemento de la cola\n"
                    + "Presione 7 para recorrer la cola\n"
                    + "Presione 9 para salir");

            opciones = Integer.parseInt(JOptionPane.showInputDialog("Inserte la opción a realizar"));
            switch (opciones) {
                case 1:

                    coli.meterDatos();
                    coli2.meterDatos();
                    coli3.meterDatos();

                    miLifo.push(coli);
                    miLifo.push(coli2);
                    miLifo.push(coli3);

                    break;

                case 2:
                    ColasLifo cachar1 = miLifo.peek();
                    JOptionPane.showMessageDialog(null, "El nombre es: " + cachar1.getNickName());
                    JOptionPane.showMessageDialog(null, "Raza : " + cachar1.getRaza());
                    JOptionPane.showMessageDialog(null, "Clase : " + cachar1.getClase());
                    JOptionPane.showMessageDialog(null, "Build : " + cachar1.getBuild());
                    JOptionPane.showMessageDialog(null, "Id: " + cachar1.getId());
                    break;

                case 3:
                    miLifo.pop();

                    break;

                case 4:
                    JOptionPane.showMessageDialog(null, "¿La cola está vacía? " + miLifo.isEmpty());

                    break;

                case 5:
                    JOptionPane.showMessageDialog(null, "¿Cuántos elementos tiene la cola: ?" + miLifo.size());

                    break;

                case 6:
                    JOptionPane.showMessageDialog(null, "¿La cola está vacía?" + miLifo.search(coli));

                    break;
                case 7:
                    for (ColasLifo mostrar : miLifo) {
                        JOptionPane.showMessageDialog(null, "Nombre: " + mostrar.getNickName());
                        JOptionPane.showMessageDialog(null, "Raza: " + mostrar.getRaza());
                        JOptionPane.showMessageDialog(null, "Clase: " + mostrar.getClase());
                        JOptionPane.showMessageDialog(null, "Build: " + mostrar.getBuild());
                        JOptionPane.showMessageDialog(null, "ID: " + mostrar.getId());
                    }

                    break;
                default:
                    JOptionPane.showMessageDialog(null, "opción incorrecta");
            }

        } while (opciones
                != 9);

    }

}
