/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package colalifo;

import javax.swing.JOptionPane;

/**
 *
 * @author iruku
 */
public class ColasLifo {

    String nickName, raza, clase, build;
    Integer id;

    public ColasLifo() {
    }

    public ColasLifo(String nickName, String raza, String clase, String build, Integer id) {
        this.nickName = nickName;
        this.raza = raza;
        this.clase = clase;
        this.build = build;
        this.id = id;
    }

    public void meterDatos() {
        
        nickName = JOptionPane.showInputDialog(null, "Nombre de personaje");
        raza = JOptionPane.showInputDialog(null, "Raza a la que pertenece");
        clase = JOptionPane.showInputDialog(null, "Clase a la que pertenece");
        build = JOptionPane.showInputDialog(null, "Build que usa");
        id = Integer.parseInt(JOptionPane.showInputDialog("ID de personaje"));

    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getRaza() {
        return raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    public String getClase() {
        return clase;
    }

    public void setClase(String clase) {
        this.clase = clase;
    }

    public String getBuild() {
        return build;
    }

    public void setBuild(String build) {
        this.build = build;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

}
