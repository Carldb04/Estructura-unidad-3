/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package colas;

import java.util.LinkedList;
import java.util.Queue;
import javax.swing.JOptionPane;

/**
 *
 * @author iruku
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        int opciones;
        Queue<Colas> personaje = new LinkedList<>();
        Colas in = new Colas();
        Colas in2 = new Colas();
        Colas in3 = new Colas();
        //   personaje.add(new Colas("Mark Zucaritas", "Guerrero", "Breaker", "Espameo", 14827));
        //   Colas usr = personaje.poll();
        //  System.out.println(usr.getNickName());

        do {
            JOptionPane.showMessageDialog(null, "Oprime 1 para agregar Datos\n"
                    + "presione 2 para mirar el primer dato de la cola Fifo\n"
                    + "presione 3 para eliminar el primer elemento de la cola Fifo\n"
                    + "presione 4 para verificar si la cola está vacía\n"
                    + "presione 5 para ver la cantidad de elementos que tiene la fila\n"
                    + "presione 6 para ver todos los elementos de la fila\n"
                    + "Presione 7 para limpiar la cola\n"
                    + "Presione 0 para salir");

            opciones = Integer.parseInt(JOptionPane.showInputDialog("Inserte la opción a realizar"));
            switch (opciones) {
                case 1:
                    in.meterDatos();
                    in2.meterDatos();
                    in3.meterDatos();

                    personaje.add(in);
                    personaje.add(in2);
                    personaje.add(in3);

                    System.out.println("datos guardados");
                    System.out.println(personaje);
                    break;

                case 2:
                    Colas pj2 = personaje.peek();
                    JOptionPane.showMessageDialog(null, "El nombre es: " + pj2.getNickName());
                    JOptionPane.showMessageDialog(null, "Raza : " + pj2.getRaza());
                    JOptionPane.showMessageDialog(null, "Clase : " + pj2.getClase());
                    JOptionPane.showMessageDialog(null, "Build : " + pj2.getBuild());
                    JOptionPane.showMessageDialog(null, "Id: " + pj2.getId());

                    break;

                case 3:
                    personaje.poll();

                    break;

                case 4:
                    JOptionPane.showMessageDialog(null, "¿La cola está vacía?  " + personaje.isEmpty());

                    break;

                case 5:
                    JOptionPane.showMessageDialog(null, "¿Cuántos elementos tiene mi cola?  " + personaje.size());
                    break;

                case 6:
                    for (Colas mostrar : personaje) {
                        JOptionPane.showMessageDialog(null, "Nombre: " + mostrar.getNickName());
                        JOptionPane.showMessageDialog(null, "Raza: " + mostrar.getRaza());
                        JOptionPane.showMessageDialog(null, "Clase: " + mostrar.getClase());
                        JOptionPane.showMessageDialog(null, "Build: " + mostrar.getBuild());
                        JOptionPane.showMessageDialog(null, "ID: " + mostrar.getId());
                    }

                    break;
                case 7:
                    personaje.clear();
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "opción incorrecta");

            }

        } while (opciones != 0);

    }

}
