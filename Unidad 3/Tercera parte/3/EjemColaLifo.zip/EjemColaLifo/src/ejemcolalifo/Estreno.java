/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejemcolalifo;

import javax.swing.JOptionPane;

/**
 *
 * @author
 */
public class Estreno {

    /*
    Se plantea el estreno de una pelicula de talla mundial
    llamada Spiderman no way home, en la cual se juntarán
    los 3 spiderman interpretados por cada actor, a la cual
    asistirán muchas personas de la ciudad.
    En este ejercicio se le venderá la boleta a cada cliente
    en el orden lifo es decir que el último en llegar es el primero en salir
     */
    String nombre, entrada;
    Integer celular, cedula, edad;

    public Estreno() {

    }

    public Estreno(String nombre, String entrada, Integer celular, Integer cedula, Integer edad) {
        this.nombre = nombre;
        this.entrada = entrada;
        this.celular = celular;
        this.cedula = cedula;
        this.edad = edad;
    }

    public void PedirDatos() {
        nombre = JOptionPane.showInputDialog("Nombre: ");
        edad = Integer.parseInt(JOptionPane.showInputDialog("Edad: "));
        entrada = JOptionPane.showInputDialog("Entrada: ");
        celular = Integer.parseInt(JOptionPane.showInputDialog("celular: "));
        cedula = Integer.parseInt(JOptionPane.showInputDialog("Cedula: "));

    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEntrada() {
        return entrada;
    }

    public void setEntrada(String entrada) {
        this.entrada = entrada;
    }

    public Integer getCelular() {
        return celular;
    }

    public void setCelular(Integer celular) {
        this.celular = celular;
    }

    public Integer getCedula() {
        return cedula;
    }

    public void setCedula(Integer cedula) {
        this.cedula = cedula;
    }

    public Integer getEdad() {
        return edad;
    }

    public void setEdad(Integer edad) {
        this.edad = edad;
    }

}
