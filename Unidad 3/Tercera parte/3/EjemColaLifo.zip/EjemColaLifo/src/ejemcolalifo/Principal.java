/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejemcolalifo;

import java.util.Stack;
import javax.swing.JOptionPane;

/**
 *
 * @author iruku
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Stack<Estreno> lifo = new Stack<>();
        Estreno cliente = new Estreno();
        Estreno cliente2 = new Estreno();
        Estreno cliente3 = new Estreno();

        cliente.PedirDatos();
        cliente2.PedirDatos();
        cliente3.PedirDatos();

        lifo.push(cliente);
        lifo.push(cliente2);
        lifo.push(cliente3);

        JOptionPane.showMessageDialog(null, "¿La cola está vacía?  " + lifo.isEmpty());
        JOptionPane.showMessageDialog(null, "¿Cuántos elementos tiene mi cola?  " + lifo.size());

        Estreno clie = lifo.peek();
        JOptionPane.showMessageDialog(null, "Nombre: " + clie.getNombre());
        JOptionPane.showMessageDialog(null, "Edad: " + clie.getEdad());
        JOptionPane.showMessageDialog(null, "Entrada: " + clie.getEntrada());
        JOptionPane.showMessageDialog(null, "Celular: " + clie.getCelular());
        JOptionPane.showMessageDialog(null, "Cedula: " + clie.getCedula());

        Estreno clien = lifo.pop();
        JOptionPane.showMessageDialog(null, "Nombre: " + clien.getNombre());
        JOptionPane.showMessageDialog(null, "Edad: " + clien.getEdad());
        JOptionPane.showMessageDialog(null, "Entrada: " + clien.getEntrada());
        JOptionPane.showMessageDialog(null, "Celular: " + clien.getCelular());
        JOptionPane.showMessageDialog(null, "Cedula: " + clien.getCedula());

    }

}
