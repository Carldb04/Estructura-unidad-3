/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejcolafifo;

import java.util.LinkedList;
import java.util.Queue;
import javax.swing.JOptionPane;

/**
 *
 * @author iruku
 */
public class EjColaFifo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Queue<EstrenoPeli> cliente = new LinkedList<>();
        EstrenoPeli peli = new EstrenoPeli();
        EstrenoPeli peli2 = new EstrenoPeli();
        EstrenoPeli peli3 = new EstrenoPeli();

        peli.PedirDatos();
        peli2.PedirDatos();
        peli3.PedirDatos();

        cliente.offer(peli);
        cliente.offer(peli2);
        cliente.offer(peli3);

        JOptionPane.showMessageDialog(null, "¿La cola está vacía?  " + cliente.isEmpty());
        JOptionPane.showMessageDialog(null, "¿Cuántos elementos tiene mi cola?  " + cliente.size());

        EstrenoPeli clien2 = cliente.peek();
        JOptionPane.showMessageDialog(null, "Nombre: " + clien2.getNombre());
        JOptionPane.showMessageDialog(null, "Edad: " + clien2.getEdad());
        JOptionPane.showMessageDialog(null, "Entrada: " + clien2.getEntrada());
        JOptionPane.showMessageDialog(null, "Celular: " + clien2.getCelular());
        JOptionPane.showMessageDialog(null, "Cedula: " + clien2.getCedula());

        EstrenoPeli clien = cliente.poll();
        JOptionPane.showMessageDialog(null, "Nombre: " + clien.getNombre());
        JOptionPane.showMessageDialog(null, "Edad: " + clien.getEdad());
        JOptionPane.showMessageDialog(null, "Entrada: " + clien.getEntrada());
        JOptionPane.showMessageDialog(null, "Celular: " + clien.getCelular());
        JOptionPane.showMessageDialog(null, "Cedula: " + clien.getCedula());

        EstrenoPeli clien3 = cliente.poll();
        JOptionPane.showMessageDialog(null, "Nombre: " + clien3.getNombre());
        JOptionPane.showMessageDialog(null, "Edad: " + clien3.getEdad());
        JOptionPane.showMessageDialog(null, "Entrada: " + clien3.getEntrada());
        JOptionPane.showMessageDialog(null, "Celular: " + clien3.getCelular());
        JOptionPane.showMessageDialog(null, "Cedula: " + clien3.getCedula());

    }

}
