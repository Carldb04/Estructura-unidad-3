/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejemcolalifo2;

import java.util.Stack;
import javax.swing.JOptionPane;

/**
 *
 * @author iruku
 */
public class EjemColaLifo2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Stack<CorresponsalB> cliente = new Stack<>();
        CorresponsalB datos = new CorresponsalB();
        CorresponsalB datos2 = new CorresponsalB();
        CorresponsalB datos3 = new CorresponsalB();

        datos.pedirDatos();
        datos2.pedirDatos();
        datos3.pedirDatos();

        cliente.push(datos);
        cliente.push(datos2);
        cliente.push(datos3);

        JOptionPane.showMessageDialog(null, "¿Mi cola está Lifo está vacía? " + cliente.isEmpty());
        JOptionPane.showMessageDialog(null, "¿¿Cuántos elementos tiene mi cola ? " + cliente.size());

        CorresponsalB mostrar = cliente.peek();
        JOptionPane.showMessageDialog(null, "Nombre: " + mostrar.getNombre());
        JOptionPane.showMessageDialog(null, "Dirrecion: " + mostrar.getDireccion());
        JOptionPane.showMessageDialog(null, "Edad: " + mostrar.getEdad());
        JOptionPane.showMessageDialog(null, "Celular " + mostrar.getCelular());
        JOptionPane.showMessageDialog(null, "numero de cuenta: " + mostrar.getNumeroDeCuenta());

        CorresponsalB mostrar2 = cliente.pop();
        JOptionPane.showMessageDialog(null, "Nombre: " + mostrar2.getNombre());
        JOptionPane.showMessageDialog(null, "Dirrecion: " + mostrar2.getDireccion());
        JOptionPane.showMessageDialog(null, "Edad: " + mostrar2.getEdad());
        JOptionPane.showMessageDialog(null, "Celular " + mostrar2.getCelular());
        JOptionPane.showMessageDialog(null, "numero de cuenta: " + mostrar2.getNumeroDeCuenta());

        CorresponsalB mostrar3 = cliente.pop();
        JOptionPane.showMessageDialog(null, "Nombre: " + mostrar3.getNombre());
        JOptionPane.showMessageDialog(null, "Dirrecion: " + mostrar3.getDireccion());
        JOptionPane.showMessageDialog(null, "Edad: " + mostrar3.getEdad());
        JOptionPane.showMessageDialog(null, "Celular " + mostrar3.getCelular());
        JOptionPane.showMessageDialog(null, "numero de cuenta: " + mostrar3.getNumeroDeCuenta());

    }

}
