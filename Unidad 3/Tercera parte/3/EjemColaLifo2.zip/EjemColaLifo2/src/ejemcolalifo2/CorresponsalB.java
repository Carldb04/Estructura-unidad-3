/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejemcolalifo2;

import javax.swing.JOptionPane;

/**
 *
 * @author iruku
 */
public class CorresponsalB {

    /*
    El  ingreso al corresponsal bancario de una 
    respetada entidad bancaria se hace mediante 
    el sistema de el último en llegar es el primero en ser atendido
    ,pero hay varios clientes que se cuelan 
    y se roban el los lugares.
    ante la molestia de los demás clientes la entidad 
    bancaria decide implementar una solución informatica
    en la que los clientes al llegar se registran y esperan
    su turno
     */
    String nombre, direccion;
    Integer edad, celular, numeroDeCuenta;

    public CorresponsalB() {

    }

    public CorresponsalB(String nombre, String direccion, Integer edad, Integer celular, Integer numeroDeCuenta) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.edad = edad;
        this.celular = celular;
        this.numeroDeCuenta = numeroDeCuenta;
    }

    public void pedirDatos() {
        nombre = JOptionPane.showInputDialog("Nombre ");
        direccion = JOptionPane.showInputDialog("Direccion ");
        edad = Integer.parseInt(JOptionPane.showInputDialog("Edad "));
        celular = Integer.parseInt(JOptionPane.showInputDialog("Celular "));
        numeroDeCuenta = Integer.parseInt(JOptionPane.showInputDialog("Numero de cuenta "));
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public Integer getEdad() {
        return edad;
    }

    public void setEdad(Integer edad) {
        this.edad = edad;
    }

    public Integer getCelular() {
        return celular;
    }

    public void setCelular(Integer celular) {
        this.celular = celular;
    }

    public Integer getNumeroDeCuenta() {
        return numeroDeCuenta;
    }

    public void setNumeroDeCuenta(Integer numeroDeCuenta) {
        this.numeroDeCuenta = numeroDeCuenta;
    }

}
