/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pila;

import java.util.Stack;
import javax.swing.JOptionPane;

/**
 *
 * @author iruku
 */
public class Pila {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Stack<Integer> pila = new Stack<Integer>();

        JOptionPane.showMessageDialog(null, "¿Mi pila está vacía? " + pila.isEmpty());

        pila.push(1);
        pila.push(3);
        pila.push(5);
        pila.push(7);
        pila.push(9);

        for (Integer recorrer : pila) {
            JOptionPane.showMessageDialog(null, "Elementos de la pila: " + recorrer);

        }

        JOptionPane.showMessageDialog(null, "Pila " + pila);
        JOptionPane.showMessageDialog(null, "¿Está vacía la pila? " + pila.isEmpty());
        pila.pop();
        JOptionPane.showMessageDialog(null, "¿Está el 5? " + pila.search(5));
        JOptionPane.showMessageDialog(null, "¿último agregado? " + pila.peek());

    }

}
