/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejemplopila;

import javax.swing.JOptionPane;

/**
 *
 * @author iruku
 */
public class Concierto {

    /*
        Se presenta la situación de un concierto en turbayork,
        el cual es de entrada libre, sin embargo los asistentes
        deben hacer un registro antes de entrar y al este ser
        registrado y entrar debe ir colocandose en la parte trasera
        del escenario, de modo que esa zona se llene primero;
        al igual que al salir las personas que llegaron de últimas
        sean las primeras en salir al terminar el concierto
     */
    String nombre, direccion, sexo;
    Integer celular, edad;

    public Concierto() {

    }

    public Concierto(String nombre, String direccion, String sexo, Integer celular, Integer edad) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.sexo = sexo;
        this.celular = celular;
        this.edad = edad;
    }

    public void pedirDatos() {
        nombre = JOptionPane.showInputDialog("Nombre : ");
        direccion = JOptionPane.showInputDialog("Dirección : ");
        sexo = JOptionPane.showInputDialog("Sexo : ");
        celular = Integer.parseInt(JOptionPane.showInputDialog("Celular : "));
        edad = Integer.parseInt(JOptionPane.showInputDialog("Edad : "));
    }
    public void mostrarDatos(){
       /* JOptionPane.showMessageDialog(null,"Nombre: "+this.nombre);
        JOptionPane.showMessageDialog(null,"Dirección: "+this.direccion);
        JOptionPane.showMessageDialog(null,"Sexo: "+this.sexo);
        JOptionPane.showMessageDialog(null,"Celular: "+this.celular);
        JOptionPane.showMessageDialog(null,"Edad: "+this.edad);
*/
      
    }
    

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public Integer getCelular() {
        return celular;
    }

    public void setCelular(Integer celular) {
        this.celular = celular;
    }

    public Integer getEdad() {
        return edad;
    }

    public void setEdad(Integer edad) {
        this.edad = edad;
    }

}
