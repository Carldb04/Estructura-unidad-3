/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejemplopila;

import java.util.Stack;
import javax.swing.JOptionPane;

/**
 *
 * @author iruku
 */
public class EjemploPila {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int opcion;
        Stack<Concierto> pila = new Stack<Concierto>();
        Concierto fan = new Concierto();
        do {
            JOptionPane.showMessageDialog(null, "1 para comprobar si la pila está vacía\n "
                    + "2 para agregar datos\n "
                    + "3 para recorrer la pila\n "
                    + "4 para borrar el último dato de la pila\n "
                    + "5 para buscar un elemento de la pila\n "
                    + "6 para mostrar el último  elemento\n "
                    + "7 para ver cuántos elementos tiene\n "
                    + "9 para salir");

            opcion = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la opción "));
            switch (opcion) {
                case 1:
                    JOptionPane.showMessageDialog(null, "¿La pila está vacía? " + pila.isEmpty());
                    break;
                case 2:
                    fan.pedirDatos();
                    pila.push(fan);
                    break;
                case 3:
                    for (Concierto recorrer : pila) {
                        JOptionPane.showMessageDialog(null, "Elementos de la pila: " + recorrer.getNombre());
                        JOptionPane.showMessageDialog(null, "Elementos de la pila: " + recorrer.getDireccion());
                        JOptionPane.showMessageDialog(null, "Elementos de la pila: " + recorrer.getSexo());
                        JOptionPane.showMessageDialog(null, "Elementos de la pila: " + recorrer.getCelular());
                        JOptionPane.showMessageDialog(null, "Elementos de la pila: " + recorrer.getEdad());
                    }
                    break;
                case 4:
                    pila.pop();
                    break;
                case 5:
                    JOptionPane.showMessageDialog(null, "¿Está mi elemento? " + pila.search(JOptionPane.showInputDialog(""
                            + "Digite el elemento a buscar")));
                    break;
                case 6:
                    Concierto mostrar = pila.peek();
                    JOptionPane.showMessageDialog(null, "Elementos de la pila: " + mostrar.getNombre());
                    JOptionPane.showMessageDialog(null, "Elementos de la pila: " + mostrar.getDireccion());
                    JOptionPane.showMessageDialog(null, "Elementos de la pila: " + mostrar.getSexo());
                    JOptionPane.showMessageDialog(null, "Elementos de la pila: " + mostrar.getCelular());
                    JOptionPane.showMessageDialog(null, "Elementos de la pila: " + mostrar.getEdad());
                    break;
                case 7:
                    JOptionPane.showMessageDialog(null, "Elementos de la pila: " + pila.size());
                default:
                    JOptionPane.showMessageDialog(null, "opción incorrecta");

            }

        } while (opcion != 9);
    }

}
