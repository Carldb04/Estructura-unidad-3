/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package colalifoapila;

import java.util.Stack;
import javax.swing.JOptionPane;

/**
 *
 * @author iruku
 */
public class ColaLifoApila {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int opcion;
        String agregar;
        Stack<String> pila = new Stack<String>();

        do {
            JOptionPane.showMessageDialog(null, "1 para comprobar si la pila está vacía\n "
                    + "2 para agregar datos\n "
                    + "3 para recorrer la pila\n "
                    + "4 para borrar el último dato de la pila\n "
                    + "5 para buscar un elemento de la pila\n "
                    + "6 para mostrar el último  elemento\n "
                    + "7 para ver cuántos elementos tiene\n "
                    + "9 para salir");

            opcion = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la opción "));
            switch (opcion) {
                case 1:
                    JOptionPane.showMessageDialog(null, "¿La pila está vacía? " + pila.isEmpty());
                    break;
                case 2:
                    agregar = JOptionPane.showInputDialog("Agregue los datos a la pila");
                    pila.push(agregar);
                    break;
                case 3:
                    for (String recorrer : pila) {
                        JOptionPane.showMessageDialog(null, "Elementos de la pila: " + recorrer);
                    }
                    break;
                case 4:
                    pila.pop();
                    break;
                case 5:
                    JOptionPane.showMessageDialog(null, "¿Está mi elemento? " + pila.search(JOptionPane.showInputDialog(""
                            + "Digite el elemento a buscar")));
                    break;
                case 6:
                    JOptionPane.showMessageDialog(null, "último agregado: " + pila.peek());
                    break;
                case 7:
                    JOptionPane.showMessageDialog(null, "Elementos de la pila: " + pila.size());
                default:
                    JOptionPane.showMessageDialog(null, "opción incorrecta");

            }

        } while (opcion != 9);
    }

}
